#Threshold values

LOW_PH_THRESHOLD = 5.0
HIGH_PH_THRESHOLD = 7.0

LOW_WATER_FLOW_THRESHOLD = 5.0 #L/min - project succees was getting roughly 16L/min

LOW_WATER_LEVEL_THRESHOLD = 20 #20% of tank left